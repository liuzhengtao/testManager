USE seleniumui;
-- 系统信息
INSERT INTO sys_system (syscode,sysname,url1,url2,url3) 
  VALUES('S001','Selenium-Ui','/','/login/index','/noauth/index');

-- 系统模块
INSERT INTO sys_module (mdcode,mdname,orderno,syscode) 
  VALUES('S00110','基础设置',100,'S001');
INSERT INTO sys_module (mdcode,mdname,orderno,syscode) 
  VALUES('S00120','用例管理',50,'S001');

-- 系统菜单
INSERT INTO sys_menu (mncode,mdcode,mdname,mnname,isuse,url,url0,orderno,syscode) 
  VALUES('S0011010','S00110','基础设置','用户管理',1,'/user/list','/user/list#/user/toAdd#/user/toEdit',100,'S001');
INSERT INTO sys_menu (mncode,mdcode,mdname,mnname,isuse,url,url0,orderno,syscode) 
  VALUES('S0011020','S00110','基础设置','部门管理',0,'/dept/list','/dept/list#/dept/toAdd#/dept/toEdit',50,'S001');
INSERT INTO sys_menu (mncode,mdcode,mdname,mnname,isuse,url,url0,orderno,syscode) 
  VALUES('S0012010','S00120','用例管理','用例管理',1,'/slnmcase/list','/slnmcase/list#/slnmcase/chapterlist',100,'S001');
INSERT INTO sys_menu (mncode,mdcode,mdname,mnname,isuse,url,url0,orderno,syscode) 
  VALUES('S0012020','S00120','用例管理','页面模板管理',1,'/slnmpagetemp/list','/slnmpagetemp/list',200,'S001');

-- 系统菜单明细
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0011010','S0011010','/user','list',1,'用户管理-用户列表','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0011010','S0011010','/user','toAdd',1,'用户管理-新增用户页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0011010','S0011010','/user','save',1,'用户管理-新增','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0011010','S0011010','/user','toEdit',1,'用户管理-编辑用户页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0011010','S0011010','/user','update',1,'用户管理-更新用户','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0011010','S0011010','/user','delete',1,'用户管理-删除用户','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0011020','S0011020','/dept','list',1,'部门管理-部门列表','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0011020','S0011020','/dept','toAdd',1,'部门管理-新增部门页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0011020','S0011020','/dept','save',1,'部门管理-新增','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0011020','S0011020','/dept','toEdit',1,'部门管理-编辑部门页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0011020','S0011020','/dept','update',1,'部门管理-更新部门','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0011020','S0011020','/dept','delete',1,'部门管理-删除部门','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','list',1,'用例管理-用例列表','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','toAdd',1,'用例管理-新增用例页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','save',1,'用例管理-新增用例','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','toEdit',1,'用例管理-编辑用例页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','update',1,'用例管理-更新用例','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','delete',1,'用例管理-删除用例','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','toAddPage',1,'用例管理-新增页面页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','doAddPage',1,'用例管理-新增页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','toEditPage',1,'用例管理-编辑页面页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','doUpdatePage',1,'用例管理-更新页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','toCopyPage',1,'用例管理-复制页面页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','doCopyPage',1,'用例管理-复制页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','doDeletePage',1,'用例管理-删除页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','toAddLocator',1,'用例管理-新增元素页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','doAddLocator',1,'用例管理-新增元素','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','toEditLocator',1,'用例管理-编辑元素页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','doUpdateLocator',1,'用例管理-更新元素','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','doDeleteLocator',1,'用例管理-删除元素','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','exportCase2Xml',1,'用例管理-导出用例至xml文件','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','toImportCase',1,'用例管理-导入用例页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','doImportCase',1,'用例管理-导入用例','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','createDataFile',1,'用例管理-生成数据模板','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','changePageOrder',1,'用例管理-移动页面顺序','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','toCopyLocator',1,'用例管理-复制元素页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','doCopyLocator',1,'用例管理-复制元素','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','toMoveLocator',1,'用例管理-移动元素页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','doMoveLocator',1,'用例管理-移动元素','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012010','S0012010','/slnmcase','changeLocatorOrder',1,'用例管理-移动元素顺序','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','list',1,'页面模板管理-页面模板列表','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','toAdd',1,'页面模板管理-新增页面模板页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','save',1,'页面模板管理-新增页面模板','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','toEdit',1,'页面模板管理-编辑页面模板页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','update',1,'页面模板管理-更新页面模板','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','delete',1,'页面模板管理-删除页面模板','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','toCopyPage',1,'页面模板管理-复制页面模板页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','doCopyPage',1,'页面模板管理-复制页面模板','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','changePageOrder',1,'页面模板管理-移动页面模板','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','toAddLocator',1,'页面模板管理-新增元素模板页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','doAddLocator',1,'页面模板管理-新增元素模板','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','toEditLocator',1,'页面模板管理-编辑元素模板页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','doUpdateLocator',1,'页面模板管理-更新元素模板','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','toCopyLocator',1,'页面模板管理-复制元素模板页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','doCopyLocator',1,'页面模板管理-复制元素模板','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','toMoveLocator',1,'页面模板管理-移动元素模板页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','doMoveLocator',1,'页面模板管理-移动元素模板','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','doDeleteLocator',1,'页面模板管理-删除元素模板','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('S0012020','S0012020','/slnmpagetemp','changeLocatorOrder',1,'页面模板管理-移动元素模板','S001');

INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('0','0','/','',1,'首页','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('0','0','/login','index',0,'登录页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('0','0','/login','doLogin',0,'登录','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('0','0','/login','doLogout',0,'登出','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('0','0','/promptmessage','removemessage',0,'清除提示消息','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('0','0','/noauth','index',0,'无权限提示页面','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('0','0','/layui','upload',1,'layui文件上传-上传单个文件','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('0','0','/ajax/slnmcase','openBrowser',1,'用例管理-打开浏览器Ajax','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('0','0','/ajax/slnmcase','doRunPage',1,'用例管理-运行页面Ajax','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('0','0','/ajax/slnmcase','doRunCase',1,'用例管理-运行用例Ajax','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('0','0','/ajax/slnmcase','setIsquitbrowser',1,'用例管理-设置是否退出浏览器Ajax','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('0','0','/ajax/slnmcase','setIsRunPage',1,'用例管理-设置页面是否运行Ajax','S001');
INSERT INTO sys_menumx (mnmxcode,mncode,contorller,method,authflag,remark,syscode) 
  VALUES('0','0','/','settheme',1,'设置主题','S001');

-- 用户权限
INSERT INTO sys_userqx (usercode,mncode,contorller,method,syscode) 
  VALUES('system','S0011010','/user','list','S001');
INSERT INTO sys_userqx (usercode,mncode,contorller,method,syscode) 
  VALUES('system','S0012010','/slnmcase','list','S001');
INSERT INTO sys_userqx (usercode,mncode,contorller,method,syscode) 
  VALUES('system','S0012020','/slnmpagetemp','list','S001');

-- 部门信息
INSERT INTO sys_dept (deptcode,pdeptcode,deptname,isuse,telno,faxno,email,remark,optcode,createtime) 
  VALUES('0000','0','管理员部门',1,'05710000001','','','','system',now());
-- 用户信息
INSERT INTO sys_user (usercode,username,userpwd,isadmin,isuse,deptcode,telno,mobileno,email,remark,optcode,createtime) 
  VALUES('system','系统管理员','96e79218965eb72c92a549dd5a330112',1,1,'0000','05710000001','15600000001','','','system',now());
